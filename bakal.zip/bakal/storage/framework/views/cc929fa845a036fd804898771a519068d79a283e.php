

<?php $__env->startSection('content'); ?>
  
<?php
    use Illuminate\Support\Facades\Auth;
?>


Jste přihlášen jako zákazník.

<?php if(auth()->guard('subscriber')->check()): ?>
    <?php echo e(auth('subscriber')->user()->login); ?>

<?php endif; ?>

<?php if(auth()->guard()->check()): ?>
    sfasf
<?php endif; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/subscribers/welcome.blade.php ENDPATH**/ ?>
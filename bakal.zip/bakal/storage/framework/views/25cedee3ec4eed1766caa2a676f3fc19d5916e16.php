

<?php $__env->startSection('content'); ?>
  
<?php
    use Illuminate\Support\Facades\Auth;
?>


<h1 class="text-center display-2">Úspěšně přihlášen do systému jako zaměstnanec</h1>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/employees/welcome.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  
<?php
  use Carbon\Carbon;
?>
        
    <h1>Práce na zakázce</h1>

   <table class="table">
      <thead>
        <tr>
       
          <th scope="col">ID objednávky</th>
          <th scope="col">Zaměstnanec</th>
          <th scope="col">Typ práce</th>
          <th scope="col">Datum</th>
          <th scope="col">Doba práce</th>
          <?php if(auth()->guard('admin')->check()): ?>
            <th scope="col">Smazat</th>
          <?php endif; ?>
          <?php if(auth()->guard('employee')->check()): ?>
            <th scope="col">Smazat</th>
          <?php endif; ?>

          

        </tr>
      </thead>
      <tbody>
          
            
                <?php $__currentLoopData = $orderworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>    

                    <?php echo e($orderwork->order->id); ?>

                  

                    </td>      
                    <td>
                      <?php echo e($orderwork->employee->name); ?> <?php echo e($orderwork->employee->surname); ?>

                    </td>
                    <td>
                      <?php echo e($orderwork->work_type); ?> </td>
                  
                    <td>    

                      <?php echo e(\Carbon\Carbon::parse($orderwork->date)->format('d.m.Y')); ?>

                    
  
                      </td>     
                      <td>    

                        <?php echo e($orderwork->time); ?>

                      
    
                        </td>    
                        <td>
                          <form action="<?php echo e(route('orderWork.destroy', $orderwork->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Odstranit</button>
                        </form>
                        </td>
                      </tr> 

                     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            

          

   

        
      </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/orderwork/index.blade.php ENDPATH**/ ?>
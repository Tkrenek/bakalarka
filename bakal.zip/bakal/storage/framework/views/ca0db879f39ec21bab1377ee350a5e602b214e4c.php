

<?php $__env->startSection('content'); ?>
  
<?php
    use Illuminate\Support\Facades\Auth;
?>

<h2 class="display-2 text-center mb-5">Jste přihlášen jako zákazník.</h2>




    <?php echo e(auth('customer')->user()->login); ?>

    <?php echo e(auth('customer')->user()->address); ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/customers/welcome.blade.php ENDPATH**/ ?>
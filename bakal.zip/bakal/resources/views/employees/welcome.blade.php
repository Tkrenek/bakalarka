@extends('layouts.navigation')

@section('content')
  
@php
    use Illuminate\Support\Facades\Auth;
@endphp


<h1 class="text-center display-2">Úspěšně přihlášen do systému jako zaměstnanec</h1>






@endsection
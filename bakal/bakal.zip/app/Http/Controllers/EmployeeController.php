<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use Illuminate\Support\Facades\Route;

use Illuminate\Support\Facades\Auth;


use Carbon\Carbon;

class EmployeeController extends Controller
{
    public function create()
    {
        $departments = Department::get();

        return view('employees.create', [
            'departments' => $departments
        ]);
    }

    public function index()
    {
        $employees = Employee::get();


        return view('employees.index', [
            'employees' => $employees
        ]);

    }

    public function edit($id)
    {
        $employee = Employee::where('id', $id)->first();
        return view('employees.update', [
            'employee' => $employee
        ]);


    }

    

    public function update(Request $request, $id)
    {
    
   
    $this->validate($request, [
            'name' => 'required',
            'surname' =>'required',
            'phone' => 'required|numeric',
            'email' => 'required|email',
    
            'function' =>'required',
   
            
        ]);
 
        //$dt = Carbon::create($request->year, $request->month, $request->day);

    

        $empl = Employee::find($id);

        $empl->name = $request->name;
        $empl->surname = $request->surname;
        $empl->phone = $request->phone;

        $empl->email = $request->email;
        $empl->function = $request->function;        
      
        $empl->birth_date = $request->birth_date;

    

        $empl->save();
        if(auth('employee')->user()) {
           
            return view('employees/welcome');
        }
        $employees = Employee::get();
        
        return view('employees.index', [
            'employees' => $employees
        ]);
      
    }

    public function destroy($id)
    {
        $empl = Employee::find($id);
        $empl->delete();

        return back();
    }

    public function store(Request $request)
    {
    
    $this->validate($request, [
           'name' => 'required',
            'surname' =>'required',
            'phone' => 'required|numeric|unique:employees',
            'email' => 'required|email|unique:employees',
            'password' => 'required|confirmed',
            'function' =>'required',
            'birth_date' => 'required'
            
            
        ]);
        $department = Department::where('name', $request->department)->first();


        
        //$dt = Carbon::create($request->year, $request->month, $request->day);
  
        Employee::create([
          
            'name' => $request->name,
            'surname' => $request->surname,
            'phone' => $request->phone,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'function' => $request->function,
            'birth_date' => $request->birth_date,
            'department_id' => $department->id,

        ]);

        


        return redirect('employees/index');
    }

  
    public function change_password()
    {
        return view('employees.change_password');
    }

    public function update_password(Request $request, $id)
    {
        $employee = Employee::find($id);
        

        
        $this->validate($request, [
            'password_old' => 'required',
            'password' => 'required|confirmed',
         
        ]);

        
        if(Hash::check($request->password_old, $employee->password)) {
            $employee->password = Hash::make($request->password);
            $employee->save();
            return back();
        } else {
            return back()->with('error', 'Zadáno chybné staré heslo');
        }

    }

    public function change_passwordAdmin($emplId)
    {
        $employee = Employee::find($emplId);

        return view('employees.change_passwordAdmin', [
            'employee' => $employee
        ]);
    }
    
    public function update_passwordAdmin(Request $request, $id)
    {
        
        $this->validate($request, [
            'password' => 'required|confirmed',
         
        ]);
        $employee = Employee::find($id);
        $employee->password = Hash::make($request->password);
        $employee->save();
           
       
            return back();
        
    }



}

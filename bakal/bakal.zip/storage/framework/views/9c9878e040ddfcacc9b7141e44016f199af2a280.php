

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard('admin')->check()): ?>
<a class="btn btn-secondary" href="<?php echo e(route('productOriginal.create')); ?>" class="p-3">Přidat originální produkt</a>
<a class="btn btn-secondary float-right" href="<?php echo e(route('productMixed.create')); ?>" class="p-3">Přidat míchaný produkt</a>
<?php endif; ?>


  <h1 class="display-3 text-center mb-5">Originální produkty</h1>    
   <table class="table  mb-5">
      <thead>
        <tr>
          <th scope="col">Kód</th>
          <th scope="col">Název</th>
          <th scope="col">Na skladě</th>
          <th scope="col">Odvětví</th>
          <th scope="col">Cena(Kč)</th>
          <th scope="col">Dodavatel</th>
          <?php if(auth()->guard('admin')->check()): ?>
            
            <th scope="col">Naskladnit</th>
            <th scope="col">Upravit</th>
            <th scope="col">Odstranit</th>

          <?php endif; ?>
          <?php if(auth()->guard('employee')->check()): ?>
            
            <th scope="col">Naskladnit</th>

          <?php endif; ?>          
        </tr>
      </thead>
      <tbody>
        <?php
          $isFirst = true;
        ?>
         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            if($isFirst) {
              $isFirst = false;
              continue;
            }  
          ?>  
       
        <tr>
          <td><?php echo e($product->code); ?></td>
          <td><?php echo e($product->name); ?></td>
          <td><?php echo e($product->on_store); ?></td>
          <td><?php echo e($product->branch); ?></td>
          <td><?php echo e($product->prize); ?></td>
          <td><?php echo e($product->producer->name); ?></td>
          
          <?php if(auth()->guard('admin')->check()): ?>
          <td style="width: 150px">
            <form action="<?php echo e(route('productOriginal.addStore', $product->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group ">
                
                <label for="ammount" class="sr-only">Množsví</label>
                <input type="text"  id="ammount" name="ammount" class="form-control <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <div class="invalid-feedback">
                  <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      Musíte zadat množství.
         
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>  
                </div>
              <button type="submit" class="btn btn-secondary">Naskladnit</button>
            </form>
          </td>
            <td><a href="<?php echo e(route('productOriginal.edit', $product->id)); ?>" type="submit" class="btn btn-secondary">Upravit</a></td>
           
            <td>
              <form action="<?php echo e(route('productOriginal.destroy', $product->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Odstranit</button>
            </form>
            </td>
          <?php endif; ?>

          <?php if(auth()->guard('employee')->check()): ?>

          <td style="width: 150px">
            <form action="<?php echo e(route('productOriginal.addStore', $product->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group">
                
                <label for="ammount" class="sr-only">Množsví</label>
                <input type="number"  id="ammount" name="ammount" class="form-control <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <div class="invalid-feedback">
                  <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      Musíte zadat množství.
         
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>  
                </div>
              <button type="submit" class="btn btn-secondary">Naskladnit</button>
            </form>
          </td>
         
          <?php endif; ?>
          
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>

    <h1 class="display-3 text-center mb-5">Míchané produkty</h1> 
  
    <table class="table">
      <thead >
        <tr>
          <th scope="col">Kód</th>
          <th scope="col">Název</th>
          <th scope="col">Na skladě</th>
          <th scope="col">Odvětví</th>
          <th scope="col">Cena(Kč)</th>
          <th scope="col">Recept</th>
          <?php if(auth()->guard('admin')->check()): ?>
            
            <th scope="col">Upravit recept</th>
            <th scope="col">Naskladnit</th>
            <th scope="col">Upravit</th>
            
            <th scope="col">Odstranit</th>
          <?php endif; ?>

          <?php if(auth()->guard('employee')->check()): ?>
           
            <th scope="col">Naskladnit</th>
            
          <?php endif; ?>
          
        </tr>
      </thead>
      <tbody>
        <?php
          $isFirst = true;
        ?>
         <?php $__currentLoopData = $productsMixed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
           if($isFirst) {
          $isFirst = false;
          continue;
        } 
         ?>
          
       
        <tr>
          <td><?php echo e($product->code); ?></td>
          <td><?php echo e($product->name); ?></td>
          <td><?php echo e($product->on_store); ?></td>
          <td><?php echo e($product->branch); ?></td>
          
          <td><?php echo e($product->prize); ?></td>
         
          <td>
            <?php $__currentLoopData = $product->mixingProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $originals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($originals->productOriginal->code); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
          </td>
         
            

          <?php if(auth()->guard('admin')->check()): ?>
          <td><a href="<?php echo e(route('mixingProduct.show', $product->id)); ?>" type="submit" class="btn btn-secondary">Změnit recept</a></td>
            <td style="width: 150px">
              <form action="<?php echo e(route('productMixed.addStore', $product->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
           
                  <label for="ammount" class="sr-only">Množství</label>
                  <input type="number"  id="ammount" name="ammount" class="form-control <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <div class="invalid-feedback">
                    <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        Musíte zadat množství.
           
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>  
                  </div>
                <button type="submit " class="btn btn-secondary">Naskladnit</button>
              </form>
            </td>
            <td><a href="<?php echo e(route('productMixed.edit', $product->id)); ?>" type="submit" class="btn btn-secondary">Upravit</a></td>
            
            <td>
              <form action="<?php echo e(route('productMixed.destroy', $product->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Odstranit</button>
            </form>
          </td>
          <?php endif; ?>

          <?php if(auth()->guard('employee')->check()): ?>
          
          <td style="width: 150px">
            <form action="<?php echo e(route('productMixed.addStore', $product->id)); ?>" method="post">
               <?php echo csrf_field(); ?>
               <?php echo method_field('PUT'); ?>
               <div class="form-group">
               
                <label for="ammount" class="sr-only">Množství</label>
                <input type="number"  id="ammount" name="ammount" class="form-control <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <div class="invalid-feedback">
                  <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      Musíte zadat množství.
         
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>  
                </div>
               <button type="submit" class="btn btn-secondary">Naskladnit</button>
            </form>
          </td>
          
          
          <?php endif; ?>
          
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/originalProduct/index.blade.php ENDPATH**/ ?>
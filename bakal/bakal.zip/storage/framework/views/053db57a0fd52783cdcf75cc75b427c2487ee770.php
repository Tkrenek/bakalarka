

<?php $__env->startSection('content'); ?>
  
<h1 class="text-center mb-5 display-2">Moje kontatní osoby </h1>
<div class="d-flex justify-content-center">
        
   <table class="table">
      <thead>
        <tr>
       
          <th scope="col">Jméno</th>
          <th scope="col">Příjmení</th>
          <th scope="col">Email</th>
          <th scope="col">Telefon</th>
          <th scope="col">Datum narození</th>
          <th scope="col">Společnost</th>
          <th scope="col">Upravit</th>
          <th scope="col">Smazat</th>
          
        </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
       
        <tr>
          
          <td><?php echo e($contact->name); ?></td>
          <td><?php echo e($contact->surname); ?></td>
          <td><?php echo e($contact->email); ?></td>
          <td><?php echo e($contact->phone); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($contact->birth_date)->format('d.m.Y')); ?></td>
          <td><?php echo e($contact->customer->name); ?></td>
          <td><a href="<?php echo e(route('contact.edit', $contact->id)); ?>" type="submit" class="btn btn-primary">Upravit profil</a></td>
          <td>
             <form action="<?php echo e(route('contact.destroy', $contact->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Smazat</button>
            </form>
          
          
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>
  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/contact/subindex.blade.php ENDPATH**/ ?>
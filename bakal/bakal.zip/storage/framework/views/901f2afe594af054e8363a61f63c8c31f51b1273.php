

<?php $__env->startSection('content'); ?>
  

        
  <h1>Recepty produktů</h1>
   <table class="table">
      <thead>
        <tr>
       
          <th scope="col">Kód produktu</th>
          <th scope="col">Recept</th>
          
   
        </tr>
      </thead>
      <tbody>
           
                <?php $__currentLoopData = $mixeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mixed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($mixed->id == 1): ?>
                  
                <?php else: ?>
                  <tr>
                    <td>    

                    <?php echo e($mixed->code); ?>

                  

                    </td>      
                    
                    <td>
                        <?php $__currentLoopData = $mixed->mixingProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            (<?php echo e($mix->productOriginal->code); ?>)
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>    
                <?php endif; ?>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
      </tbody>
    </table>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/mixingProduct/index.blade.php ENDPATH**/ ?>
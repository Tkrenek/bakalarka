

<?php $__env->startSection('content'); ?>
  
<?php
  use Carbon\Carbon as carbon;
?>

<h1 class="display-2 text-center mb-5">Přehled objednávek</h1>
<div class="row">
  <div class="col">
    <form action="<?php echo e(route('orders.store')); ?>" method="post"  class="">
      <?php echo csrf_field(); ?>
      <?php if(auth()->guard('customer')->check()): ?>
        <button type="submit" class="btn btn-outline-secondary mb-5">Vytvořit novou objednávku</button>
      <?php endif; ?>
      
    </form> 
  </div>
  
  <div class="col">
    <form action="<?php echo e(route('orders.index.filter')); ?>" type="get" class="float-right mb-5">
      <div class="row">
        <div class="col">
          <input type="search" class="form-control mr-sm-2" name="query" placeholder="Zadejte ID">
        </div>
        <div class="col">
          <button class="btn btn-primary" type="submit" class="float-right">Vyhledat</button>
        </div>
      </div>
      <?php if($message = Session::get('error')): ?>
              <div class="mt-2 text-danger">
                  <strong><?php echo e($message); ?>  </strong>  
              </div>
                                            
      <?php endif; ?>

    </form>
  </div>
  
</div>

   <table class="table table-bordered">
      <thead>
        <tr>
       
          <th scope="col">ID objednávky</th>
          <th scope="col">Zákazník</th>
          <th scope="col">Stav objednávky</th>
          <th scope="col">Termín objednávky</th>
          <th scope="col">Celková cena</th>
          <th scope="col">Faktura</th>
          <?php if(auth()->guard('admin')->check()): ?>
          
          <th scope="col">Odstranit objednávku</th>
       
          <th scope="col">Upravit objednávku</th>
          <?php endif; ?>
          <?php if(auth()->guard('employee')->check()): ?>
          
            <th scope="col">Označit práci</th>
            <th scope="col">Změnit stav objednávky</th>
            
          <?php endif; ?>
          <?php if(auth()->guard('customer')->check()): ?>
            <th scope="col">Změnit termín</th>
           <!-- <th scope="col">Upravit objednávku</th> -->
          <?php endif; ?>
          
        </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
       
        <tr>
           
          <td><a href="<?php echo e(route('orders.show', $order->id)); ?>"><?php echo e($order->id); ?></a></td> 
          <td><?php echo e($order->customer->name); ?></td> 
          <td><?php echo e($order->state); ?></td>
          <td><?php echo e(Carbon::parse($order->term)->format('d.m. Y')); ?> </td>
          <td>
            <?php
              $sum = 0;
              $sumPckg = 0;
            ?>
            <?php $__currentLoopData = $order->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $item->packageItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                  
                    $sumPckg += $pc->container->prize * $pc->count
                  
                  ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php
                  if($item->is_mixed == "ano") {
                    $sum += $item->amount * $item->productMixed->prize;
                  } else {
                    $sum += $item->amount * $item->productOriginal->prize;
                  }
              ?>
                
              
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($sum + $sumPckg); ?> Kč
           </td>
           <?php if(auth()->guard('admin')->check()): ?>
           <td>
             <?php if($order->invoice != "bude doplněno"): ?>
              <a href="<?php echo e(route('orders.downloadInvoice', $order->invoice)); ?>"><?php echo e($order->invoice); ?></a>
             <?php endif; ?>
            <form method="post" action="<?php echo e(route('orders.uploadFile', $order->id)); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="invoice">Vyberte fakturu</label>
                <input type="file" class="form-control-file" id="invoice" name="invoice">
              </div>
              <button class="btn btn-primary">Nahrát</button>
            </form>
          </td>
           <?php endif; ?>
           <?php if(auth()->guard('employee')->check()): ?>
           <td>
            <?php if($order->invoice != "bude doplněno"): ?>
            <a href="<?php echo e(route('orders.downloadInvoice', $order->invoice)); ?>"><?php echo e($order->invoice); ?></a>
           <?php endif; ?>
            <form method="post" action="<?php echo e(route('orders.uploadFile', $order->id)); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="invoice">Vyberte fakturu</label>
                <input type="file" class="form-control-file" id="invoice" name="invoice">
              </div>
              <button class="btn btn-primary">Nahrát</button>
            </form>
          </td>
           <?php endif; ?>
           <?php if(auth()->guard('customer')->check()): ?>
           <td>
           <?php if($order->invoice == "bude doplněno"): ?>

              Bude doplněno

           <?php else: ?>   
            <a href="<?php echo e(route('orders.downloadInvoice', $order->invoice)); ?>">Stáhnout Fakturu</a>
           <?php endif; ?>
           
           
           </td>
             
           <?php endif; ?>
          
          <?php if(auth()->guard('admin')->check()): ?>
            <td>
              <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Odstranit objednávku</button>
            </form>
            </td>
          <?php endif; ?>
          

          
            <?php if(auth()->guard('employee')->check()): ?>
            <td>

              <a href="<?php echo e(route('orderWork.create', $order->id)); ?>" type="btn" class="btn btn-secondary">Označit</a>
            </td>
            <td>
            <form action="<?php echo e(route('orders.changeState', $order->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group">
               <label for="state" >Stav</label>
               <select name="state" id="state" class="form-control custom-select">
                 <option id="založeno" name="založeno">založeno</option class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                 <option id="namícháno" name="namícháno">namícháno</option class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                 <option id="zabaleno" name="zabaleno">zabaleno</option class="form-control <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                
            </select> 
       
               <div class="invalid-feedback">
                <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      
                Je nutné vybrat stav.
      
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>  
               </div>
              <button type="submit" class="btn btn-secondary">Změnit stav objednávky</button>
              </form>
            </td>
          <?php endif; ?>
        
            
          
<?php if(auth()->guard('admin')->check()): ?>

<td>
    <a href="<?php echo e(route('orders.edit', $order->id)); ?>">Upravit objednávku(Admin)</a>
</td>
</td>
<?php endif; ?>

<?php if(auth()->guard('customer')->check()): ?>
<td>

  <form action="<?php echo e(route('orders.changeTerm', $order->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
      <label for="term">Změnit termín</label>
      <input type="date" id="term" name="term" class="<?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control" >
      <div class="invalid-feedback">
          <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

              Je nutné zadat datum.

          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>  
  </div>
    <button type="submit" class="btn btn-secondary">Změnit termín objednávky</button>
    
</form>
</td>
<!--
  <td>
    <a href="<?php echo e(route('orders.edit', $order->id)); ?>" type="submit" class="btn btn-secondary">Změnit objednávku</a>
</td>
-->
<?php endif; ?>


           
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/orders/index.blade.php ENDPATH**/ ?>
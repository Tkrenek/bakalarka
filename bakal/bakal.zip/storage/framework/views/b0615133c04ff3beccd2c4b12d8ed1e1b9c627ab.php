

<?php $__env->startSection('content'); ?>
  
<div class="justify-content-center d-flex p-5"><h1 class="display-1">Informační systém Coloral</h1></div>
<div class="justify-content-center d-flex p-1 login-option">Jste zákazník? Klikněte: <a href="/"> zde </a>.</div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
            <div class="card-header text-center">Přihlášení zaměstnance</div>

            <div class="card-body">
            <form  action="<?php echo e(route('employees.login.post')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col">
                        
                        <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-danger alert-block">
                            <strong><?php echo e($message); ?>  </strong>   
                        </div>    
                        
                        
                    <?php endif; ?>
                <div class="form-group">
                    
                    <label for="email">Email</label>
                    <input type="text" id="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" name="email">
                    <div class="invalid-feedback">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            Musíte zadat e-mail. 
            
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>     
                </div>

           
                <div class="form-group">
                    
                    <label for="password" class=>Heslo</label>
                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  type="password" id="password" name="password">
                    <div class="invalid-feedback">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            
                                Musíte zadat heslo.
                            
                         
            
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
               
                
                <div class="d-flex justify-content-center p-3">
                    <button type="submit" class="btn btn-primary">Přihlásit se</button>

                </div>
            </form>
    
       

            </div>

            </div>
           
        </div> 
    </div>
    
</div>
<div class="login-option">Přístup pro admina: <a href="<?php echo e(route('admins.login')); ?>">zde</a>.</div> 

</div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/employees/login.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  
<div class="d-flex justify-content-center">
        
   <table class="table table-bordered table-hover">
      <thead>
        <tr>
       
          <th scope="col">Jméno
           
          </th>
          <th scope="col">Příjmení</th>
          <th scope="col">Email</th>
          <th scope="col">Telefon</th>
          <th scope="col">Datum narození</th>
          <th scope="col">Oddělení</th>
          <th scope="col">Označit práci</th>
          <th scope="col">Upravit</th>
          <th scope="col">Změnit heslo</th>
          <th scope="col">Smazat</th>
          
        </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
       
        <tr>
          
          <td><?php echo e($employee->name); ?></td>
          <td><?php echo e($employee->surname); ?></td>
          <td><?php echo e($employee->email); ?></td>
          <td><?php echo e($employee->phone); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($employee->birth_date)->format('d.m.Y')); ?></td>
          <td><?php echo e($employee->department->name); ?></td>
          <td><a href="<?php echo e(route('orderWork.admin.create', $employee->id)); ?>" type="submit" class="btn btn-secondary">Označit práci</a></td>
          <td><a href="<?php echo e(route('employees.edit', $employee->id)); ?>" type="submit" class="btn btn-secondary">Upravit profil</a>
            <td> <a href="<?php echo e(route('employees.change_password.admin', $employee->id)); ?>" type="submit" class="btn btn-secondary">Změnit heslo</a></td>
       
          <td>
             <form action="<?php echo e(route('employees.destroy', $employee->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Smazat</button>
            </form>
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>
  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/employees/index.blade.php ENDPATH**/ ?>
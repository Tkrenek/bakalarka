

<?php $__env->startSection('content'); ?>
    <p><a href="#" class="text-white bg-dark">White link</a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/ahoj.blade.php ENDPATH**/ ?>
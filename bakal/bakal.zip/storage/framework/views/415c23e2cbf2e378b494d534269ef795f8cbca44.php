

<?php $__env->startSection('content'); ?>
  
<div class="text-center text-danger" style="font-size: larger;">

  <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    Musíte vybrat množství ve správném formátu.
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>

<a href="<?php echo e(route('orders.show', $order->id)); ?>" class="btn btn-primary">Vrátit se zpět</a>

<a href="<?php echo e(route('items.createOriginal', $order->id)); ?>" class="btn btn-primary float-right ml-2">Pouze originální</a>
<a href="<?php echo e(route('items.createMixed', $order->id)); ?>" class="btn btn-primary float-right ">Pouze Míchané</a>


<h1 class="display-3 text-center mb-5">Originální produkty</h1>    
  <div class="row">
    <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-block alert-danger color-danger text-center">
                            <strong><?php echo e($message); ?>  </strong>   
                        </div>    
                        
                        
                    <?php endif; ?>
  </div>
  
   <table class="table mb-5">
      <thead>
        <tr>
          <th scope="col">Kód</th>
          <th scope="col">Název</th>
          <th scope="col">Na skladě</th>
          <th scope="col">Odvětví</th>
          <th scope="col">Cena(Kč)</th>
          <th scope="col">Dodavatel</th>
          <?php if(auth()->guard('admin')->check()): ?>
          <th scope="col">Vybrat</th>
        <?php endif; ?>
          <?php if(auth()->guard('customer')->check()): ?>
            <th scope="col">Vybrat</th>
          <?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php
          $isFirst = true;
          ?>

         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
         if($isFirst) {
        $isFirst = false;
        continue;
        } 
       ?>
       
        <tr>
          <td><?php echo e($product->code); ?></td>
          <td><?php echo e($product->name); ?></td>
          <td><?php echo e($product->on_store); ?></td>
          <td><?php echo e($product->branch); ?></td>
          <td><?php echo e($product->prize); ?></td>
          <td><?php echo e($product->producer->name); ?></td>
          <td style="width: 150px">
             
            <form action="<?php echo e(route('items.store', ['orderid'=>$order->id,'productcode'=>$product->code])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="ammount" >Množsví</label>
                    <div class="row">
                        <div class="col">   
                            <input placeholder="množství" style="width: 170px" type="text"  id="ammount" name="ammount" class="mb-3 form-control ">
                            
                        
                      </div>
                        <div class="col">
                            <button type="submit" class="btn btn-primary">Přidat k objednávce</button>
                        </div>
                    </div>
              </form>

          </td>
         
          
  
          
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>

    <h1 class="display-3 text-center mb-5"> Míchané produkty</h1> 
  
    <table class="table mb-5">
      <thead >
        <tr>
          <th scope="col">Kód</th>
          <th scope="col">Název</th>
          <th scope="col">Na skladě</th>
          <th scope="col">Odvětví</th>
          <th scope="col">Cena(Kč)</th>
          
          <?php if(auth()->guard('admin')->check()): ?>
          <th scope="col">Vybrat</th>
        <?php endif; ?>
          <?php if(auth()->guard('customer')->check()): ?>
            <th scope="col">Vybrat</th>
          <?php endif; ?>
          
        </tr>
      </thead>
      <tbody>
          <?php
          $isFirst = true;
          ?>
         <?php $__currentLoopData = $productsMixed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
         
         <?php
           if($isFirst) {
          $isFirst = false;
          continue;
          } 
         ?>
       
        <tr>
          <td><?php echo e($product->code); ?></td>
          <td><?php echo e($product->name); ?></td>
          <td><?php echo e($product->on_store); ?></td>
          <td><?php echo e($product->branch); ?></td>
          
          <td><?php echo e($product->prize); ?></td>
          <td style="width: 150px">
          <form action="<?php echo e(route('items.store', ['orderid'=>$order->id,'productcode'=>$product->code])); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">

                <label for="ammount" >Množsví</label>
                <div class="row">
                    <div class="col">   
                        <input placeholder="množství" style="width: 170px" type="text"  id="ammount" name="ammount" class="mb-2 form-control " >
                        
                     
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary">Přidat k objednávce</button>
                    </div>
                </div>
                
              </div>
            
          </form>
          </td>
          
          

         
          
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/items/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
            <div class="card-header text-center">Změna hesla</div>

            <div class="card-body"> 
            <form  action="<?php echo e(route('customers.update_passwordAdmin', $customer->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
               
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block text-center">
                    <strong ><?php echo e($message); ?></strong>   
                </div>    
                
                
            <?php endif; ?>
                <div class="form-group">
                    
                    <label for="password" class=>Nové heslo</label>
                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  type="password" id="password" name="password">
                    <div class="invalid-feedback">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php if($message == "The password confirmation does not match."): ?> 
                                Hesla se neshodují.
                            <?php else: ?>
                                Musíte zadat heslo.
                            <?php endif; ?>
                         
            
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    
                    <label for="password_confirmation">Ověření hesla</label>
                    <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password_confirmation" id="password_confirmation" >
                    <div class="invalid-feedback">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php if($message == "The password confirmation does not match."): ?> 
                                Hesla se neshodují.
                            <?php else: ?>
                                Musíte zadat heslo.
                            <?php endif; ?>
                         
            
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>    
                </div>
                
                <div class="d-flex justify-content-center p-3">
                    <button type="submit" class="btn btn-primary ">Změnit heslo</button>

                </div>
            </form>
        

            </div>

            </div>
        </div>
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/customers/change_passwordAdmin.blade.php ENDPATH**/ ?>
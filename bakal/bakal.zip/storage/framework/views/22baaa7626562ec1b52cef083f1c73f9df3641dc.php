

<?php $__env->startSection('content'); ?>
  

        
   
   <?php if($item->is_mixed == "ano"): ?>
      <h2 class="display-2 text-center">Položka: <?php echo e($item->productMixed->code); ?></h2>
   <?php else: ?>
      <h2 class="display-2 text-center">Položka: <?php echo e($item->productOriginal->code); ?></h2>
   <?php endif; ?>

   <div class="text-center text-danger" style="font-size: larger;">

      <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          Musíte zadat množství!
             
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
   
   
 
   <a type="button" class="btn btn-primary mb-3" href="<?php echo e(route('orders.show', $item->order->id)); ?>">Zpět na objednávku</a>

   <a class="btn btn-primary float-right" href="<?php echo e(route('packageItem.create', $item->id )); ?>" role="button">Přidat balení</a>
  
   <table class="table">
      <thead>
         <th scope="col">Kód nádoby</th>
      <th scope="col">Typ</th>
      <th scope="col">Objem</th>
      <th scope="col">Počet</th>
      <th scope="col">Změnit počet</th>
      <th scope="col">Odstranit</th>
      </thead>
      <tbody>

      
      
         <?php $__currentLoopData = $item->packageItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pckg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td>
               <?php echo e($pckg->container->code); ?>

            </td>
            <td>
               <?php echo e($pckg->container->type); ?>

            </td>
            <td>
               <?php echo e($pckg->container->bulk); ?> l
            </td>
            <td>
               <?php echo e($pckg->count); ?> ks
            </td>
            
               <td style="width: 200px">
                  <form action="<?php echo e(route('packageItem.changeCount', $pckg->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PUT'); ?>
                  <div class="form-group">
                    
                    <input placeholder="počet" style="width: 175px;" type="number"   id="count" name="count" class="form-control">
                   
                    </div>
                  <button type="submit" class="btn btn-primary" >Změnit</button>
               </form>
               </td>
            
            <td>
               <form action="<?php echo e(route('packageItem.destroy', $pckg->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-danger">Smazat</button>
              </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      </tbody>
   </table>

  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/packageItem/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('subscribers.login')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label for="login">Login</label>
        <input type="text" id="login" name="login">

        <label for="password">heslo</label>
        <input type="text" id="password" name="password">

        <button type="submit" class="btn btn-primary">Přihlásit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/loginodber.blade.php ENDPATH**/ ?>
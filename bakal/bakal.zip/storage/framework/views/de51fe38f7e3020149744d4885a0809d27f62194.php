

<?php $__env->startSection('content'); ?>
  

        
<a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary float-right">Zpět na seznam produktů</a>
   
   <h1 class="display-3 text-center mb-5">Kód produktu : <?php echo e($mixedProduct->code); ?></h1>
   
   <div class="row">
        <div class="col-8">
            <h3>Přidat novou přísadu: </h3>
            <form action="<?php echo e(route('mixingProduct.store', $mixedProduct->id)); ?>" method="post">
        
           
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="col-lg-2">
                        <label for="code">Kód produktu</label>
                        <select name="code" id="code" class="form-control custom-select" style="width: 200px">
                            <?php $__currentLoopData = $originals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $original): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($original->id != 1): ?>
                                <option id="<?php echo e($original->code); ?>" name="<?php echo e($original->code); ?>"><?php echo e($original->code); ?></option class="form-control <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php endif; ?>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select> 
                        
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        
                                <strong>Musíte zadat kód produktu.</strong>
                
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                       
                            <?php if($message = Session::get('error')): ?>
                                <div>
                                    <span class="text-danger"><?php echo e($message); ?></span>  
                                </div>    
                                
                                
                            <?php endif; ?>
                            
                      </div>
                  
                  </div>
                <button type="submit" class="btn btn-primary ml-3">Přidat</button>
            </form>
        </div>
        <div class="col-4">
            <h3>Přísady:</h3>
  
    
        <table class="table" style="width: 400px">
          <thead>
              <th class="col">Kód přísady</th>
              <th class="col">Smazat</th>
          </thead>
          <tbody>
                <?php $__currentLoopData = $mixedProduct->mixingProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($prod->productOriginal->code); ?>

                    </td>
                    <td>
                        
                        <form action="<?php echo e(route('mixingProduct.destroy', $prod->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Odstranit</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
          </tbody>
        </table>

        </div>

   </div>
    
    
   

  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/mixingProduct/show.blade.php ENDPATH**/ ?>
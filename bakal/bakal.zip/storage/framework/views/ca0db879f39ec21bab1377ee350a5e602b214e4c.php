

<?php $__env->startSection('content'); ?>
  
<?php
    use Illuminate\Support\Facades\Auth;
?>

<h2 class="display-2 text-center mb-5">Úspěšně přihlášen do systému</h2>

<div class="text-center welcome-text">
    Název společnosti: <?php echo e(auth('customer')->user()->name); ?> <br>
    Adresa: <?php echo e(auth('customer')->user()->address); ?>, <?php echo e(auth('customer')->user()->town); ?> <br>
    Login: <?php echo e(auth('customer')->user()->login); ?> <br>
</div>

<h5 class="display-5 text-center mt-3">Vyberte svoji další akci</h5>
<hr>
<div class="row">
    <div class="col-sm-4">
        <div class="card">
          <div class="card-body text-center">
            <h5 class="card-title">Seznam objenávek</h5>
            <p class="card-text">Zobrazte si svoje objednávky</p>
            <a  class="btn btn-primary"  href="<?php echo e(route('orders.myindex',  auth('customer')->user()->id )); ?>">Přejít</a>
          </div>
        </div>
      </div>
    <div class="col-sm-4">
      <div class="card ">
        <div class="card-body text-center">
          <h5 class="card-title">Seznam nádob</h5>
          <p class="card-text">Prohédněte si seznam nádob, které jsou nabízeny.</p>
          <a  href="<?php echo e(route('containers.index')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="card ">
        <div class="card-body text-center">
          <h5 class="card-title">Seznam produktů</h5>
          <p class="card-text">Prohlédněte si seznam nabízených produktů.</p>
          <a  href="<?php echo e(route('product.index')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>
    
</div>
  
  <div class="row mt-2">
    
    <div class="col-sm-4 offset-2">
      <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Přidat kontaktní osobu</h5>
          <p class="card-text">Přidejte do systému další kontaktní osoby.</p>
          <a href="<?php echo e(route('contact.create')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>
 

    <div class="col-sm-4">
      <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Zobrazit osoby</h5>
          <p class="card-text">Zobrazte si své kontaktní osoby.</p>
          <a href="<?php echo e(route('contact.index.sub', auth('customer')->user()->id)); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>
  </div>
    




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/customers/welcome.blade.php ENDPATH**/ ?>
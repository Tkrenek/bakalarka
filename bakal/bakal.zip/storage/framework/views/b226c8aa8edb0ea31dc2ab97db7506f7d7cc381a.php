

<?php $__env->startSection('content'); ?>
  
<h1 class="display-3 text-center mb-4">Přehled nádob</h1>

<?php if(auth()->guard('admin')->check()): ?>
  <a class="btn btn-secondary mb-3" href="<?php echo e(route('containers.create')); ?>" class="p-3">Přidat nádobu</a>
<?php endif; ?>


  <table class="table">
    <thead>
      <tr>
     
        <th scope="col">Typ nádoby</th>
        <th scope="col">Objem(v litrech)</th>
        <th scope="col">Na skladě</th>
        <th scope="col">Cena</th>
        <?php if(auth()->guard('admin')->check()): ?>
          <th scope="col">Upravit</th>
          <th scope="col">Naskladnit</th>
          <th scope="col">Odstranit</th>
        <?php endif; ?>
        <?php if(auth()->guard('employee')->check()): ?>
          <th scope="col">Naskladnit</th>
        <?php endif; ?>
        
      </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
     
      <tr>
        
        <td><?php echo e($container->type); ?></td>
        <td><?php echo e($container->bulk); ?> (litr)</td>
        <td><?php echo e($container->on_store); ?> ks</td>
        <td><?php echo e($container->prize); ?> Kč</td>
 
        <?php if(auth()->guard('employee')->check()): ?>
        
        
          <td class="pr-0 mr-0" style="width: 150px">
            <form action="<?php echo e(route('containers.addStore', $container->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group">
               
                <label for="ammount" class="sr-only">Množství</label>
                <input type="number" style="width: 125px"  id="ammount" name="ammount" class="form-control <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <div class="invalid-feedback">
                  <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      Musíte zadat množství.
         
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>  
                </div>
              <button type="submit" class="btn btn-secondary">Naskladnit</button>
          </form>
          </td>
          
        <?php endif; ?>
        <?php if(auth()->guard('admin')->check()): ?>
        
          <td><a href="<?php echo e(route('containers.edit', $container->id)); ?>" type="submit" class="btn btn-secondary">Upravit</a></td>
          <td style="width: 200px">
            <form action="<?php echo e(route('containers.addStore', $container->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
             
              <label for="ammount" class="sr-only">Množství</label>
              <input type="number"  id="ammount" name="ammount" class="form-control  <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
              <div class="invalid-feedback">
                <?php $__errorArgs = ['ammount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    Musíte zadat množství.
       
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>  
              </div>
            <button type="submit" class="btn btn-secondary">Naskladnit</button>
        </form>
          </td>
        <td>
          <form action="<?php echo e(route('containers.destroy', $container->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Smazat</button>
        </form>
        </td>
        <?php endif; ?>
        
    </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>


   
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/containers/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
<?php
$orderSum = 0;
?>
<h1 class="text-center mb-5 display-2">ID objednávky: <?php echo e($order->id); ?></h1>
<?php if(auth()->guard('customer')->check()): ?>
<a href="<?php echo e(route('orders.myindex', auth('customer')->user()->id )); ?>" role="button" class="btn btn-primary">Zpět na moje objednávky</a>
<?php endif; ?>
<?php if(auth()->guard('admin')->check()): ?>
<a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary mb-3">Zpět na  objednávky</a>
<?php endif; ?>
<?php if(auth()->guard('employee')->check()): ?>
<a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary mb-3">Zpět na  objednávky</a>
<?php endif; ?>
<?php if(auth()->guard('customer')->check()): ?>
<a class="btn btn-primary float-right mb-3" href="<?php echo e(route('items.create', $order->id)); ?>" role="button">Přidat položku</a>
<?php endif; ?>
<?php if(auth()->guard('admin')->check()): ?>
<a class="btn btn-primary float-right mb-3" href="<?php echo e(route('items.create', $order->id)); ?>" role="button">Přidat položku</a>
<?php endif; ?>
<table class="table">
   <thead>
      <th scope="col">Kód produktu</th>
      <th scope="col">Název produktu</th>
      <th scope="col">Množství(v litrech)</th>
      <th scope="col">Cena</th>
      <th scope="col">Cena za balení</th>
      <th scope="col">Celková cena</th>
      <th scope="col">Balení</th>
      <?php if(auth()->guard('admin')->check()): ?>
      <th scope="col">Vybrat balení</th>
      <th scope="col">Odstranit</th>
      <?php endif; ?>
      <?php if(auth()->guard('customer')->check()): ?>
      <th scope="col">Vybrat balení</th>
      <th scope="col">Odstranit</th>
      <?php endif; ?>
   </thead>
   <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
      <?php if($item->is_mixed == "ano"): ?>
      <td><?php echo e($item->productMixed->code); ?></td>
      <td><?php echo e($item->productMixed->name); ?></td>
      <?php else: ?>
      <td><?php echo e($item->productOriginal->code); ?></td>
      <td><?php echo e($item->productOriginal->name); ?></td>
      <?php endif; ?>
      <td><?php echo e($item->amount); ?></td>
      <?php
      $sumProduct = 0;
      ?>
      <td>
         <?php if($item->is_mixed == "ano"): ?>
         <?php
         $sumProduct = $item->amount * $item->productMixed->prize
         ?>
         <?php else: ?>
         <?php
         $sumProduct = $item->amount * $item->productOriginal->prize
         ?>
         <?php endif; ?>
         <?php echo e($sumProduct); ?> 
         Kč
      </td>
      <?php
      $sumPckg = 0;
      ?>
      <td>
         <?php $__currentLoopData = $item->packageItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pckg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php
         $sumPckg += $pckg->count * $pckg->container->prize;
         ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($sumPckg); ?> Kč
      </td>
      <td>
         <?php echo e($sumPckg + $sumProduct); ?> Kč
         <?php
         $orderSum += $sumPckg + $sumProduct
         ?>
      </td>
      <td>
         <?php $__currentLoopData = $item->packageItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($cont->container->type); ?> - <?php echo e($cont->container->bulk); ?>l(<?php echo e($cont->count); ?>ks)
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
      <?php if(auth()->guard('admin')->check()): ?>
      <td><a href="<?php echo e(route('packageItem.show', $item->id)); ?>" role="button" class="btn btn-primary">Upravit balení</a>
      <td>
         <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Smazat</button>
         </form>
      </td>
      <?php endif; ?>
      <?php if(auth()->guard('customer')->check()): ?>
      <td><a href="<?php echo e(route('packageItem.show', $item->id)); ?>" role="button" class="btn btn-primary">Upravit balení</a>
      <td>
         <form action="<?php echo e(route('items.destroy', $item->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Smazat</button>
         </form>
      </td>
      <?php endif; ?>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<h5  class="float-right">Celková cena: <?php echo e($orderSum); ?> Kč</h5>
<?php if(auth()->guard('customer')->check()): ?>
<?php
$pole = array()
?>
<?php if(empty($recommended)): ?>
<?php else: ?>
<h3>Často nakupované položky s vaším zbožím:</h3>
<?php $__currentLoopData = $recommended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(in_array($one[0], $pole)): ?>
<?php else: ?> 
<span class="recommended">
<?php echo e($one[0]); ?>  &nbsp 
</span>
<?php endif; ?>
<?php
array_push($pole, $one[0])
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php endif; ?>
<?php if(auth()->guard('admin')->check()): ?>
<?php
$pole = array();
$konec = 0;   
?>
<?php if(empty($recommended)): ?>
<?php else: ?>
<h3>Doporučené položky:</h3>
<?php $__currentLoopData = $recommended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(in_array($one[0], $pole)): ?>
<?php else: ?> 
<span class="recommended">
<?php echo e($one[0]); ?>  &nbsp
</span>
<?php endif; ?>
<?php
array_push($pole, $one[0])
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/orders/show.blade.php ENDPATH**/ ?>
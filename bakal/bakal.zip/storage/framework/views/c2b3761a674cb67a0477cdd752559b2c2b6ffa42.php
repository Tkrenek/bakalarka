

<?php $__env->startSection('content'); ?>
  
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
            <div class="card-header text-center">Označit práci na objedávce</div>

            <div class="card-body"> 
                <?php if(auth()->guard('admin')->check()): ?>
                    <form action="<?php echo e(route('orderWork.admin.store', $employee->id)); ?>" method="POST">
                <?php endif; ?>
                <?php if(auth()->guard('employee')->check()): ?>
                    <form action="<?php echo e(route('orderWork.store', $order->id)); ?>" method="POST">
                <?php endif; ?>
    
        <?php echo csrf_field(); ?>

        <?php if(auth()->guard('admin')->check()): ?>
        <div class="form-group ">
                            
            <label for="order">ID objednávky</label>
            <input type="text" id="order" name="order" class="form-control <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('order')); ?>">
            <div class="invalid-feedback">
                <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    Musíte zadat ID objednávky. 
    
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>  
        </div>
        <?php endif; ?>

                
                <div class="form-group ">
                    
                    <label for="type">Typ práce na objednávce</label>
                    
                    <select name="type" id="type" class="form-control custom-select">
                        
                        <option id="míchání" name="míchání">Míchání</option>
                        <option id="balení" name="balení">Balení</option>
                        <option id="expedice" name="expedice">Expedice</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="date">Datum vykonání činnosti</label>
                    <input type="date" id="date" name="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('date')); ?>">
                    <div class="invalid-feedback">
                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            Musíte zadat datum. 
            
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                </div>

                <div class="form-group">
                    <label for="time">Zadejte počet hodin</label>
                    <input type="number" id="time" name="time" class="form-control <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('time')); ?>">
                    <div class="invalid-feedback">
                        <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                            Musíte zadat čas. 
            
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>  
                </div>


                <div class="d-flex justify-content-center p-3">
                    <button type="submit" class="btn btn-primary">Označit práci</button>

                </div>
        </form>
       

            </div></div></div></div></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/orderwork/create.blade.php ENDPATH**/ ?>
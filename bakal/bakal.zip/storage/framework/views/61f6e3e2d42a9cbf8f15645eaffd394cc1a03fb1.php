

<?php $__env->startSection('content'); ?>
  

  <table class="table">
    <thead>
      <tr>
     
        <th scope="col">Typ nádoby</th>
        <th scope="col">Objem(v litrech)</th>
        <th scope="col">Na skladě</th>
        <th scope="col">Cena</th>

        <?php if(auth()->guard('admin')->check()): ?>
            <th scope="col">Vybrat</th>
        <?php endif; ?>
        <?php if(auth()->guard('customer')->check()): ?>
            <th scope="col">Vybrat</th>
        <?php endif; ?>
        
      </tr>
    </thead>
    <tbody>
       <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
     
      <tr>
        
        <td><?php echo e($container->type); ?></td>
        <td><?php echo e($container->bulk); ?></td>
        <td><?php echo e($container->on_store); ?></td>
        <td><?php echo e($container->prize); ?></td>
        <td>
            
            <form action="<?php echo e(route('packageItem.store', ['itemid' => $itemid, 'containerid' => $container->id])); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="form-group ">
  
                  <label for="count" >Množsví</label>
                  <div class="row">
                      <div class="col">   
                          <input type="text"  id="count" name="count" class="form-control <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                          <div class="invalid-feedback">
                            <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                Musíte zadat množství.
                   
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>  
                      </div>
                      <div class="col">
                          <button type="submit" class="btn btn-secondary">Přidat balení</button>
                      </div>
                  </div>
                <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
  
                Musíte vybrat množství.
        
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              
            </form>
            </td>
        
       
        
    </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
  </table>


   
  


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/packageItem/create.blade.php ENDPATH**/ ?>
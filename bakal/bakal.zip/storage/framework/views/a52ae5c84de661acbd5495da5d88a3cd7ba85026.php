

<?php $__env->startSection('content'); ?>
  
<?php
  use Carbon\Carbon as carbon;
?>

<h1 class="display-2 text-center mb-5">Seznam oddělení</h1>

    <a class="btn btn-secondary mb-3" href="<?php echo e(route('departments.create')); ?>">Přidat Oddělení</a>
   <table class="table text-center">
      <thead>
        <tr>
       
          <th scope="col">Název oddělení</th>
          <th scope="col">Počet pracovníků</th>
          <th scope="col">Odstranit</th>
       
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php echo e($department->name); ?>

                </td>
                <td>
                    
                    <?php echo e($count2 = \DB::table('employees')->where('department_id', '=', $department->id)->count()); ?>

                </td>
                <td>
                    <form action="<?php echo e(route('departments.destroy', $department->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Odstranit</button>
                    </form>
                    
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
      </tbody>
    </table>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/departments/index.blade.php ENDPATH**/ ?>
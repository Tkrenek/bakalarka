

<?php $__env->startSection('content'); ?>
  
<?php
    use Illuminate\Support\Facades\Auth;
    use Carbon\Carbon as carbon;
?>


<h2 class="display-2 text-center mb-5">Úspěšně přihlášen do systému</h2>

<div class="text-center welcome-text">
    Jméno a příjmení: <?php echo e(auth('employee')->user()->name); ?> <?php echo e(auth('employee')->user()->surname); ?> <br>
    Datum narození: <?php echo e(Carbon::parse(auth('employee')->user()->birth_date)->format('d.m. Y')); ?> <br>
    Email: <?php echo e(auth('employee')->user()->email); ?>  <br>
    Telefon: <?php echo e(auth('employee')->user()->phone); ?>  <br>
    Funkce: <?php echo e(auth('employee')->user()->function); ?>  <br>
    
   

</div>

<h5 class="display-5 text-center mt-3">Vyberte svoji další akci</h5>
<hr>
<div class="row">
    <div class="col-sm-4">
        <div class="card">
          <div class="card-body text-center">
            <h5 class="card-title">Seznam objenávek</h5>
            <p class="card-text">Zobrazte si všechny objednávky, které v systému jsou</p>
            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary">Přejít</a>
          </div>
        </div>
      </div>
    <div class="col-sm-4">
      <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Seznam nádob</h5>
          <p class="card-text">Prohédněte si seznam nádob, které jsou nabízeny.</p>
          <a  href="<?php echo e(route('containers.index')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Seznam produktů</h5>
          <p class="card-text">Prohlédněte si seznam nabízených produktů.</p>
          <a  href="<?php echo e(route('product.index')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>
</div>
  
  <div class="row mt-2">
   
    <div class="col-sm-4">
      <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Recepty</h5>
          <p class="card-text">Zobrazte si recepty míchaných produktů.</p>
          <a href="<?php echo e(route('mixingProduct.index')); ?>"  class="btn btn-primary">Přejít</a>
        </div>
      </div>
    </div>

  <div class="col-sm-4">
    <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Odvedená práce</h5>
          <p class="card-text">Zobrazte si svoji práci na objednávkách.</p>
          <a href="<?php echo e(route('orderWork.index')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
  </div>
<div class="col-sm-4">
    <div class="card">
        <div class="card-body text-center">
          <h5 class="card-title">Google kalendář</h5>
          <p class="card-text">Temíny objednávek ve vašem google kalendáři.</p>
          <a href="<?php echo e(route('google.index')); ?>" class="btn btn-primary">Přejít</a>
        </div>
      </div>
</div>
</div>


        
    


 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/employees/welcome.blade.php ENDPATH**/ ?>
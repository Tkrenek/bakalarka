

<?php $__env->startSection('content'); ?>
  
<?php
    use Illuminate\Support\Facades\Auth;
?>


<h3 class="display-3 text-center mb-5">Jste přihlášen jako správce</h3>

<div class="text-center">
    Jméno a příjmení: <?php echo e(auth('admin')->user()->name); ?> <?php echo e(auth('admin')->user()->surname); ?> <br />
        Telefon: <?php echo e(auth('admin')->user()->phone); ?><br />
        Email: <?php echo e(auth('admin')->user()->email); ?>

</div>

        
      


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/admins/success.blade.php ENDPATH**/ ?>
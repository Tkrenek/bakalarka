

<?php $__env->startSection('content'); ?>
  
<div class="d-flex justify-content-center">
        
            <form action="<?php echo e(route('odberatele.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">Ahoj</div>
                
                <div class="form-group row">
                    
                    <label for="nazev" class="col-md-4 col-form-label">Název společnosti</label>
                    <?php $__errorArgs = ['nazev'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                    <?php echo e($message); ?>

            
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="text" value="<?php echo e(old('nazev')); ?>" id="nazev" name="nazev">
                </div>
                <div class="form-group row">
                    <?php $__errorArgs = ['mesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <?php echo e($message); ?>

            
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="mesto" class="sr-only">Město</label>
                    <input type="text" value="<?php echo e(old('mesto')); ?>" id="mesto" name="mesto" >
                </div>
                <div class="form-group row">
                    <?php $__errorArgs = ['adresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <?php echo e($message); ?>

            
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="adresa" class="sr-only">Adresa</label>
                    <input type="text" id="adresa" value="<?php echo e(old('adresa')); ?>" name="adresa">
                </div>
                <div class="form-group row">
                    <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <?php echo e($message); ?>

            
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="login" class="sr-only">Login</label>
                    <input type="text" id="login" value="<?php echo e(old('login')); ?>" name="login">
                </div>
                <div class="form-group row">
                    
                    <label for="password" class="sr-only">password</label>
                    <input type="password" id="password"  name="password">
                </div>
                
                <div class="form-group row">
                    <?php $__errorArgs = ['heslo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <?php echo e($message); ?>

            
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="password_confirmation">pass conf</label>
                    <input type="password" name="password_confirmation" id="password_confirmation" placeholder="Your confirm password">
                </div>
                <div class="form-group row">
                    <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                        <?php echo e($message); ?>

            
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <label for="url" class="sr-only">URL</label>
                    <input type="text" value="<?php echo e(old('url')); ?>" id="url" name="url" >
                </div>
                <button type="submit" class="btn btn-primary">Vytvořit</button>
            </form>
       
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/odberatele/register.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  
<div class="d-flex justify-content-center">
        
           
       <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          Jméno: <?php echo e($employee->name); ?> Příjmení: <?php echo e($employee->surname); ?> Oddělení: <?php echo e($employee->department->name); ?>

          <a href="<?php echo e(route('employee/show/')); ?>"></a>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/employees\index.blade.php ENDPATH**/ ?>
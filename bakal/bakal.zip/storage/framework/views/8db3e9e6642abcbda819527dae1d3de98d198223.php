

<?php $__env->startSection('content'); ?>
  
<div class="d-flex justify-content-center">
        
   <table class="table">
      <thead>
        <tr>
       
          <th scope="col">Jméno</th>
          <th scope="col">Město</th>
          <th scope="col">Adresa</th>
          <th scope="col">URL</th>
          <th scope="col">Upravit</th>
          <th scope="col">Změnit heslo</th>
          <th scope="col">Nová objednávka</th>
          <th scope="col">Nová kontaktní osoba</th>
          <th scope="col">Odstranit</th>
        </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
       
        <tr>
          
          <td><?php echo e($customer->name); ?></td>
          <td><?php echo e($customer->town); ?></td>
          <td><?php echo e($customer->address); ?></td>
          <td><?php echo e($customer->url); ?></td>
          <td><a href="<?php echo e(route('subscribers.edit', $customer->id)); ?>" type="submit" class="btn btn-secondary">Upravit účet</a></td>
          <td><a href="<?php echo e(route('subscribers.change_passwordAdmin', $customer->id)); ?>" type="submit" class="btn btn-secondary">Změnit heslo</a></td>
          <td>
            <form action="<?php echo e(route('orders.admin.store', $customer->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-secondary">Vytvořit objednávku</button>
            </form> 
         </td>
         <td>
          <a href="<?php echo e(route('contact.admin.create', $customer->id)); ?>" type="btn" class="btn btn-secondary">Přidat osobu</a> 
       </td>
         
          <td>
             <form action="<?php echo e(route('subscribers.destroy', $customer->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Odstranit</button>
            </form>
          </td>
          
         
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>
  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/subscribers/index.blade.php ENDPATH**/ ?>
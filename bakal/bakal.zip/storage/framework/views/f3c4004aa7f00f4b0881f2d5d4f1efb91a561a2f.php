

<?php $__env->startSection('content'); ?>

<h2 class="display-2 text-center">Seznam dodavatelů</h2>

<a class="btn-secondary btn mb-3" href="<?php echo e(route('producers.create')); ?>" class="p-3">Přidat dodavatele</a>
<div class="d-flex justify-content-center">
  
   <table class="table">
      <thead>
        <tr>
       
          <th scope="col">Název </th>
          <th scope="col">Email</th>
          <th scope="col">Telefon</th>
          <th scope="col">Adresa</th>
          <th scope="col">Upravit</th>
          <th scope="col">Smazat</th>
          
        </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $producers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
       
        <tr>
          
          <td><?php echo e($producer->name); ?></td>
          <td><?php echo e($producer->email); ?></td>
          <td><?php echo e($producer->phone); ?></td>
          <td><?php echo e($producer->address); ?>, <?php echo e($producer->town); ?></td>

          <td><a href="<?php echo e(route('producers.edit', $producer->id)); ?>" type="submit" class="btn btn-secondary">Upravit profil</a>

       
          <td>
             <form action="<?php echo e(route('producers.destroy', $producer->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Smazat</button>
            </form>
      </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </tbody>
    </table>
  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/producers/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>

<h1 class="display-1 text-center mb-5">Statistiky</h1>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.3/js/bootstrap-select.min.js" charset="utf-8"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js" charset="utf-8"></script>
<script src="<?php echo e(asset('chart.js/chart.js')); ?>"></script>

<?php if(auth()->guard('admin')->check()): ?>
   <div class="row mt-4 mb-5">
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Nejprodávaněší nádoby</span> 
         </div>
         <canvas id="myChart4"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Nejprodávanější produkty</span>
         </div>
         <canvas id="myChart6"></canvas>
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Nejpilnější zaměstnanci</span>
         </div>
         <canvas id="myChart3"></canvas> 
      </div>
   </div>
   <div class="row mb-5 mt-5">
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Podíl míchaných a originálních produktů (v %)</span>
         </div>
         <canvas id="myChart1"></canvas> 
      </div>
      <div class="chart-container mt-5 col-4">
         <div class="text-center mb-4">
            <span class="stats ">Největší zákazníci</span>
         </div>
         <canvas id="myChart2"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Podíl kanystrů a plechovek (v %)</span>
         </div>
         <canvas id="myChart5"></canvas> 
      </div>
   </div>
<?php endif; ?>

<?php if(auth()->guard('customer')->check()): ?>
   <div class="row mt-4 mb-5">
      <div class="chart-container col-4 offset-2">
         <div class="text-center mb-4">
            <span class="stats">Nejprodávaněší nádoby</span>
         </div>
         <canvas id="myChart4"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Nejprodávanější produkty</span>
         </div>
         <canvas id="myChart6"></canvas> 
      </div>
   </div>
   <div class="row mb-5 mt-5">
      <div class="chart-container col-4 offset-2">
         <div class="text-center mb-4">
            <span class="stats">Podíl míchaných a originálních produktů (v %)</span>
         </div>
         <canvas id="myChart1"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Podíl kanystrů a plechovek (v %)</span>
         </div>
         <canvas id="myChart5"></canvas> 
      </div>
   </div>
<?php endif; ?>

<?php if(auth()->guard('employee')->check()): ?>
   <div class="row mt-4 mb-5">
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Nejprodávaněší nádoby</span>
         </div>
         <canvas id="myChart4"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Nejprodávanější produkty</span>
         </div>
         <canvas id="myChart6"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Největší zákazníci</span>
         </div>
         <canvas id="myChart2"></canvas> 
      </div>
   </div>
   <div class="row mb-5 mt-5">
      <div class="chart-container col-4 offset-2">
         <div class="text-center mb-4">
            <span class="stats">Podíl míchaných a originálních produktů (v %)</span>
         </div>
         <canvas id="myChart1"></canvas> 
      </div>
      <div class="chart-container col-4">
         <div class="text-center mb-4">
            <span class="stats">Podíl kanystrů a plechovek (v %)</span>
         </div>
         <canvas id="myChart5"></canvas> 
      </div>
   </div>
<?php endif; ?>
<?php $label=array(); $data=array(); ?> 

<?php $__currentLoopData = $nejvic; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nej): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
   <?php
      // ulozeni jmena a poctu do samostatnych poli
      array_push($label, $nej->name);
      array_push($data, $nej->count);
   ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
   var lbl = JSON.parse('<?php echo json_encode($label); ?>'); // prevedeni dat do promennych javascriptu, ktere se daji zobrazit v grafu
   var dt = JSON.parse('<?php echo json_encode($data); ?>'); 
   var ctx1 = document.getElementById('myChart1').getContext('2d');
   // Vymodelovani grafu
   var myChart = new Chart(ctx1, { 
     type: "pie", // kolacovy graf
     data:{
         labels:["Originální", "Míchané"],
         datasets:[{
             label: "Prodkty",
             data: [<?php echo $resultsOriginal; ?>, <?php echo $resultsMixed; ?>], // data, ktera chceme zobrazit
             backgroundColor: ["#AC3131", "#254AA1", '#669966', '#FFA500', '#FFFF00'],
         }]
     },
   })
   // graf pro zobrazeni
   var ctx2 = document.getElementById('myChart2').getContext('2d');
   var myChart = new Chart(ctx2, { 
     
     type: "bar", // sloupcovy graf
     data:{
         labels: lbl,
         datasets:[{
             label: "Nejvíce objednávek",
             data: dt,
             backgroundColor: ["#AC3131", "#254AA1", "#669966", '#FFA500', '#FFFF00']
         }]
     },
   })
</script>

<?php $label1=array(); $data1=array(); ?> 

<?php $__currentLoopData = $zamestnanci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <?php
      array_push($label1, $zam->name);
      array_push($data1, $zam->count);
   ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
     var lbl = JSON.parse('<?php echo json_encode($label1); ?>'); // prevedeni dat do promennych javascriptu, ktere se daji zobrazit v grafu
     var dt = JSON.parse('<?php echo json_encode($data1); ?>');
     var ctx3 = document.getElementById('myChart3').getContext('2d');
     var myChart = new Chart(ctx3, { 
       type: "bar", // sloupovy graf
       data:{
           labels: lbl,
           datasets:[{
               label: "Zaměstnanci",
               data: dt,
               backgroundColor: ["#AC3131", "#254AA1", '#AC3131', '#FFA500', '#FFFF00'],
           }]
       },
     })
   
</script>
<?php $label=array(); $data=array(); ?>
<?php $__currentLoopData = $baleni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php
array_push($label, $bal->code);
array_push($data, $bal->count);
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
   var lbl = JSON.parse('<?php echo json_encode($label); ?>');
     var dt = JSON.parse('<?php echo json_encode($data); ?>');
     var ctx4 = document.getElementById('myChart4').getContext('2d');
     var myChart = new Chart(ctx4, { 
       
       type: "bar",
       data:{
           labels: lbl,
           datasets:[{
               label: "Nádoby",
               data: dt,
               backgroundColor: ["#AC3131", "#254AA1", '#669966', '#FFA500', '#FFFF00'],
           }]
       },
     })
</script>
<script>
   var bal1 = JSON.parse('<?php echo json_encode($baleniPomer1); ?>');
   var bal2 = JSON.parse('<?php echo json_encode($baleniPomer2); ?>');
   var ctx5 = document.getElementById('myChart5').getContext('2d');
   var myChart = new Chart(ctx5, { 
       
       type: "pie",
       data:{
           labels: ["kanystry", "plechovky"],
           datasets:[{
               label: "poměr baleni",
               data: [bal1, bal2],
               backgroundColor: ["#AC3131", "#254AA1"],
           }]
       },
   })
</script>
<?php $label=array(); $data=array(); ?>
<?php $__currentLoopData = $maximaProdukty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $max): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php
array_push($label, $max->code);
array_push($data, $max->count);
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
   var lbl = JSON.parse('<?php echo json_encode($label); ?>');
   var dat = JSON.parse('<?php echo json_encode($data); ?>');
   var ctx6 = document.getElementById('myChart6').getContext('2d');
   var myChart = new Chart(ctx6, { 
       
       type: "bar",
       data:{
           labels: lbl,
           datasets:[{
               label: "Nejprodávanější produkty",
               data: dat,
               backgroundColor: ["#AC3131", "#254AA1", "#669966", '#FFA500', '#FFFF00'],
           }]
       },
   })
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.3/js/bootstrap-select.min.js" charset="utf-8"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\tomkr\prog\bakal\bakal\resources\views/stats/index.blade.php ENDPATH**/ ?>